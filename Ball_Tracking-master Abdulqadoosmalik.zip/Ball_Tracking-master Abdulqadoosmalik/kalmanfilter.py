import numpy as np

class BallTrackerKalmanFilter(object):

    def __init__(self, initial_x, initial_y, framerate, skipframes):
        """
        Initialize the Kalman filter.

        Args:
            initial_x (float): Initial x-coordinate of the ball.
            initial_y (float): Initial y-coordinate of the ball.
            framerate (float): Frame rate of the video.
            skipframes (int): Number of frames to skip between updates.
        """
        # Time difference
        self.dt = skipframes / framerate

        # Initial state vector [x, y, vx, vy, ax, ay]
        self.state = np.array([initial_x, initial_y, 0, 0, -9.8, 0])

        # State transition matrix
        self.F = np.array([[1, 0, self.dt, 0, 0.5*self.dt**2, 0],
                           [0, 1, 0, self.dt, 0, 0],
                           [0, 0, 1, 0, self.dt, 0],
                           [0, 0, 0, 1, 0, self.dt],
                           [0, 0, 0, 0, 1, 0],
                           [0, 0, 0, 0, 0, 1]])

        # Initial process covariance matrix
        self.P = np.eye(6)  # Identity matrix of size 6x6

        # Process noise covariance matrix
        self.Q = 100 * np.eye(6)

        # Sensor matrix
        self.H = np.array([[1, 0, 0, 0, 0, 0],
                           [0, 1, 0, 0, 0, 0]])

        # Measurement noise covariance matrix
        self.R = 10 * np.eye(2)  # 2x2 Identity matrix

    def predict(self):
        """
        Predict the next state using the Kalman filter prediction step.

        Returns:
            np.ndarray: Predicted state vector.
        """
        # Predict the next state
        self.state = self.F @ self.state

        # Update the process covariance matrix
        self.P = self.F @ self.P @ self.F.T + self.Q

        return self.state

    def update(self, measured_x, measured_y):
        """
        Update the Kalman filter with new measurements.

        Args:
            measured_x (float): Measured x-coordinate of the ball.
            measured_y (float): Measured y-coordinate of the ball.

        Returns:
            np.ndarray: Updated state vector.
        """
        # Calculate Kalman gain
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)

        # Update the state based on measurements
        z = np.array([measured_x, measured_y])
        y = z - self.H @ self.state
        self.state = self.state + K @ y

        # Update the process covariance matrix
        self.P = (np.eye(6) - K @ self.H) @ self.P

        return self.state

