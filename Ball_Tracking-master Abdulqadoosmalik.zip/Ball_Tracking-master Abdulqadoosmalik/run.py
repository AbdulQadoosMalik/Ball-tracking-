import time
import cv2
from custom_object_detector import CustomObjectDetector  # Assuming custom_object_detector.py contains the CustomObjectDetector class
from custom_kalman_filter import CustomKalmanFilter  # Assuming custom_kalman_filter.py contains the CustomKalmanFilter class

def main():
    # Start the timer
    start_time = time.time()

    # Read the input video
    vid = cv2.VideoCapture('22496-22790.avi')

    # Get video properties
    fps = vid.get(cv2.CAP_PROP_FPS)
    frame_width = int(vid.get(3))
    frame_height = int(vid.get(4))

    # Initialize the custom object detector and Kalman Filter
    detector = CustomObjectDetector()
    skipframes = 1  # Number of frames skipped + 1 (Time between successive frames given for detection)
    flag = True  # To find the first detection

    track = []  # Keeps Track of most likely state vectors
    frames = []  # Stores frames of the video

    while vid.isOpened():
        ret, frame = vid.read()
        if ret:
            frames.append(frame)
            obj_center = detector.detectObject(frame)
            try:
                if len(obj_center) > 0 and flag:
                    KF = CustomKalmanFilter(obj_center[0], obj_center[1], fps, skipframes)
                    track.append(KF.xk)
                    flag = False

                xp = KF.predict()
                xmp = KF.update(obj_center[0], obj_center[1])
                track.append(xmp)
            except TypeError:
                pass
        else:
            break

    vid.release()

    print("Time to execute: %s seconds" % (time.time() - start_time))

    # Writing to video
    out = cv2.VideoWriter('tracked_video.avi', cv2.VideoWriter_fourcc('M', 'P', 'E', 'G'), 10, (frame_width, frame_height))
    for i in range(len(frames)):
        print(i)
        cv2.circle(frames[i], (int(track[i][0]), int(track[i][1])), 10, (255, 255, 255), 4)
        out.write(frames[i])

    out.release()

if __name__ == "__main__":
    main()
